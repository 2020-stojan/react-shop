import React from 'react'
import Card from '../Components/Card/component'
import data from '../TestData/index.json'

const Home = () => {
    return (
        <div className='container'>
            <div className="columns is-multiline">
                {
                    data.map((item) => (
                        <div className="column is-one-quarter">
                            <Card item={item} />
                        </div>
                    ))
                }
            </div>
        </div>


    )
}

export default Home;
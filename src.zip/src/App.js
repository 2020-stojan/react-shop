import React from 'react';
import styled from "@emotion/styled";
import './App.css';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import Header from './Components/header';
import Home from './Views/Home';
import Page from './Views/Page';
import Admin from './Views/Admin';

function App() {



  return (
    <Router>
      <Header ime={'Stojan'} broj={34} />
      <Switch>
        <Route path='/' exact component={Home} />
        <Route path="/product/:id" component={Page} />
        <Route path="/admin" component={Admin} />
      </Switch>
    </Router>
  );
}

export default App;
